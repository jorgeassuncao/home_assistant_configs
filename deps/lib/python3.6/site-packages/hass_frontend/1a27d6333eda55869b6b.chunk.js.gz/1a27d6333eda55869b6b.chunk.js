(window.webpackJsonp=window.webpackJsonp||[]).push([[18],{620:function(e,s,t){"use strict";t.r(s);var a=t(0),r=t(4);t(178),customElements.define("ha-panel-kiosk",class extends r.a{static get template(){return a["a"]`
    <partial-cards
      id='kiosk-states'
      hass='[[hass]]'
      show-menu
      route='[[route]]'
      panel-visible
    ></partial-cards>
    `}static get properties(){return{hass:Object,route:Object}}})}}]);
//# sourceMappingURL=1a27d6333eda55869b6b.chunk.js.map